import json
import os
import re
import socket
import subprocess
import sys
import time

from pymxs import runtime as rt


def ensure_requests_installed():
    try:
        import requests  # type: ignore
    except ImportError:
        print("Requests library missing. Attempting automatic configuration...")

        # Determine the exact Python executable location cross-version (2022 - 2027)
        py_exe = sys.executable
        if "3dsmax.exe" in py_exe.lower():
            max_root = os.path.dirname(py_exe)
            possible_paths = [
                os.path.join(max_root, "Python", "python.exe"),  # Max 2025+
                os.path.join(max_root, "3dsmaxpy.exe"),  # Max 2022-2024 legacy fallback
            ]
            for path in possible_paths:
                if os.path.exists(path):
                    py_exe = path
                    break

        startupinfo = None
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

        try:
            subprocess.check_call(
                [py_exe, "-m", "pip", "install", "requests"],
                startupinfo=startupinfo,
            )
        except subprocess.CalledProcessError:
            try:
                subprocess.check_call(
                    [py_exe, "-m", "ensurepip", "--default-pip"],
                    startupinfo=startupinfo,
                )
                subprocess.check_call(
                    [py_exe, "-m", "pip", "install", "requests"],
                    startupinfo=startupinfo,
                )
                print("Requests library successfully configured automatically.")
            except Exception as e:
                print(f"Failed to automatically bootstrap and install requests: {e}")


ensure_requests_installed()

_path_ = os.path.dirname(__file__).replace("\\", "/")
if _path_ not in sys.path:
    sys.path.append(_path_)

import MS_Importer
from Logging import Logger

_importerSetup_ = MS_Importer.LiveLinkImporter()

MSLIVELINK_VERSION = "5.6"

"""
Qt Import Block: Cross-compatibility framework layout
"""
try:
    from PySide6.QtCore import QRect, Qt, QThread, Signal
    from PySide6.QtGui import QIcon, QPixmap
    from PySide6.QtWidgets import QApplication, QCheckBox, QVBoxLayout, QWidget
except ImportError:
    try:
        from PySide2.QtCore import QRect, Qt, QThread, Signal  # type: ignore
        from PySide2.QtGui import QIcon, QPixmap  # type: ignore
        from PySide2.QtWidgets import QCheckBox  # type: ignore
        from PySide2.QtWidgets import QApplication, QVBoxLayout, QWidget  # type: ignore
    except ImportError:
        try:
            from PySide.QtCore import QRect, Qt, QThread, Signal  # type: ignore
            from PySide.QtGui import QApplication  # type: ignore
            from PySide.QtGui import QCheckBox  # type: ignore
            from PySide.QtGui import QIcon  # type: ignore
            from PySide.QtGui import QPixmap  # type: ignore
            from PySide.QtGui import QVBoxLayout  # type: ignore
            from PySide.QtGui import QWidget  # type: ignore
        except ImportError:
            try:
                from PyQt5.QtCore import QRect, Qt, QThread  # type: ignore
                from PyQt5.QtCore import pyqtSignal as Signal  # type: ignore
                from PyQt5.QtGui import QIcon, QPixmap  # type: ignore
                from PyQt5.QtWidgets import QApplication  # type: ignore
                from PyQt5.QtWidgets import QCheckBox  # type: ignore
                from PyQt5.QtWidgets import QVBoxLayout  # type: ignore
                from PyQt5.QtWidgets import QWidget  # type: ignore
            except ImportError:
                try:
                    from PyQt4.QtCore import SIGNAL as Signal  # type: ignore
                    from PyQt4.QtCore import QRect, Qt, QThread  # type: ignore
                    from PyQt4.QtGui import QApplication  # type: ignore
                    from PyQt4.QtGui import QCheckBox  # type: ignore
                    from PyQt4.QtGui import QIcon  # type: ignore
                    from PyQt4.QtGui import QPixmap  # type: ignore
                    from PyQt4.QtGui import QVBoxLayout  # type: ignore
                    from PyQt4.QtGui import QWidget  # type: ignore
                except ImportError:
                    raise ImportError("No suitable PyQt or PySide version found")


def GetHostApp():
    try:
        try:
            import qtmax

            mainWindow = qtmax.GetQMaxMainWindow()
        except:
            try:
                mainWindow = QWidget.find(
                    rt.windows.getMAXHWND()
                )  # works in 3ds Max 2021 and later
            except:
                mainWindow = QApplication.activeWindow()

        while True:
            lastWin = mainWindow.parent()
            if lastWin:
                mainWindow = lastWin
            else:
                break
        return mainWindow
    except:
        pass


class QLiveLinkMonitor(QThread):
    Bridge_Call = Signal()
    Instance = []

    def __init__(self):
        super(QLiveLinkMonitor, self).__init__()
        self.TotalData = b""
        QLiveLinkMonitor.Instance.append(self)

    def __del__(self):
        self.quit()
        self.wait()

    def stop(self):
        if hasattr(self, "requestInterruption"):
            self.requestInterruption()
        self.quit()
        self.wait()

    def run(self):
        time.sleep(0.025)
        try:
            host, port = "localhost", 13292
            socket_ = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            socket_.bind((host, port))

            while True:
                if (
                    hasattr(self, "isInterruptionRequested")
                    and self.isInterruptionRequested()
                ):
                    break
                socket_.listen(5)
                client, address = socket_.accept()
                data = b""
                data = client.recv(4096 * 2)
                if data:
                    self.TotalData = b""
                    self.TotalData += data
                    while True:
                        data = client.recv(4096 * 2)
                        if data:
                            self.TotalData += data
                        else:
                            break
                    time.sleep(0.05)
                    self.Bridge_Call.emit()
                    time.sleep(0.05)
        except:
            pass

    def InitializeImporter(self):
        """Initializes the importer with received asset data."""
        json_array = json.loads(self.TotalData)
        for asset_ in json_array:
            self = _importerSetup_.Identifier
            self.set_Asset_Data(asset_)
            try:
                guid = asset_["guid"]
                assetID = asset_["id"]
            except:
                guid = ""
                assetID = ""

            if len(json_array) > 1:
                bridge_event = "BRIDGE_BULK_EXPORT_ASSET"
            else:
                bridge_event = "BRIDGE_EXPORT_ASSET"

            try:
                rt.execute("clearListener()")
                Logger(
                    rt.execute("classof renderers.current"),
                    rt.maxversion()[7],
                    guid,
                    assetID,
                    bridge_event,
                )
            except:
                Logger(
                    rt.execute("classof renderers.current"),
                    "2019 or lower",
                    guid,
                    assetID,
                    bridge_event,
                )


def get_dpi_scale():
    """Returns the Windows UI scale factor (1.0, 1.25, 1.5, 2.0, etc.)."""

    try:
        import qtmax  # type: ignore

        main_win = qtmax.GetQMaxMainWindow()
        if main_win and hasattr(main_win, "screen"):
            print("Screen")
            return main_win.screen().logicalDotsPerInch() / 96.0
    except:
        pass

    try:
        from PySide6.QtGui import QGuiApplication  # type: ignore

        primary = QGuiApplication.primaryScreen()
        if primary:
            print("PySide6")
            return primary.logicalDotsPerInch() / 96.0
    except:
        pass

    try:
        from PySide2.QtGui import QGuiApplication  # type: ignore

        primary = QGuiApplication.primaryScreen()
        if primary:
            print("PySide2")
            return primary.logicalDotsPerInch() / 96.0
    except:
        pass

    return 1.0


class LiveLinkUI(QWidget):
    """Main UI class for the Megascans LiveLink plugin modified for High-DPI support."""

    Instance = []
    Settings = [0, 0, 0]

    def __init__(self, _importerSetup_, parent=GetHostApp()):
        super(LiveLinkUI, self).__init__(parent)
        LiveLinkUI.Instance = self
        self.Importer = _importerSetup_
        self._path_ = _path_
        self.setObjectName("LiveLinkUI")
        img_ = QPixmap(os.path.join(self._path_, "MS_Logo.png"))
        self.setWindowIcon(QIcon(img_))

        # Pull dynamic UI scaling properties
        self.scale = get_dpi_scale()

        font_size = int(14 * self.scale)
        indicator_size = int(14 * self.scale)
        indicator_radius = int(2 * self.scale)
        spacing_hover = int(12 * self.scale)

        self.stylesheet_ = f"""
        QCheckBox {{ background: transparent; color: #E6E6E6; font-family: Source Sans Pro; font-size: {font_size}px; }}
        QCheckBox::indicator:hover {{ border: 2px solid #2B98F0; background-color: transparent; }}
        QCheckBox::indicator:checked:hover {{ background-color: #2B98F0; border: 2px solid #73a5ce; }}
        QCheckBox:indicator{{ color: #67696a; background-color: transparent; border: 2px solid #67696a;
        width: {indicator_size}px; height: {indicator_size}px; border-radius: {indicator_radius}px; }}
        QCheckBox::indicator:checked {{ border: 2px solid #18191b; background-color: #2B98F0; color: #ffffff; }}
        QCheckBox::hover {{ spacing: {spacing_hover}px; background: transparent; color: #ffffff; }}
        QCheckBox::checked {{ color: #ffffff; }}
        QCheckBox::indicator:disabled, QRadioButton::indicator:disabled {{ border: 1px solid #444; }}
        QCheckBox:disabled {{ background: transparent; color: #414141; font-family: Source Sans Pro; font-size: {font_size}px; margin: 0px; text-align: center; }}
        QComboBox {{ color: #FFFFFF; font-size: {font_size}px; font-family: Source Sans Pro; selection-background-color: #1d1e1f; background-color: #1d1e1f; }}
        QComboBox:hover {{ color: #c9c9c9; font-size: {font_size}px; font-family: Source Sans Pro; selection-background-color: #232426; background-color: #232426; }} """

        scaled_min_width = int(250 * self.scale)
        scaled_max_width = int(330 * self.scale)
        scaled_widget_height = int(30 * self.scale)

        self.setMinimumWidth(scaled_min_width)
        self.setMaximumWidth(scaled_max_width)
        self.setWindowTitle(f"MS Plugin {MSLIVELINK_VERSION} - 3ds Max")

        try:
            if hasattr(Qt, "WindowType"):
                self.setWindowFlags(Qt.WindowType.Window)
            else:
                self.setWindowFlags(Qt.Window)
        except:
            pass

        self.style_ = """ QWidget#LiveLinkUI { background-color: #262729; } """
        self.setStyleSheet(self.style_)

        self.MainLayout = QVBoxLayout()
        self.setLayout(self.MainLayout)
        self.MainLayout.setSpacing(int(5 * self.scale))
        self.MainLayout.setContentsMargins(
            int(5 * self.scale),
            int(2 * self.scale),
            int(5 * self.scale),
            int(2 * self.scale),
        )

        # Set the checkbox options
        self.checks_l = QVBoxLayout()
        self.checks_l.setSpacing(int(2 * self.scale))
        self.MainLayout.addLayout(self.checks_l)

        self.applytoSel = QCheckBox("Apply Material to Selection")
        self.applytoSel.setToolTip(
            "Applies the imported material(s) to your selection."
        )
        self.applytoSel.setChecked(self.Importer.getPref("Material_to_Sel"))
        self.applytoSel.setFixedHeight(scaled_widget_height)
        self.applytoSel.setStyleSheet(self.stylesheet_)
        self.checks_l.addWidget(self.applytoSel)

        self.checks_l = QVBoxLayout()
        self.checks_l.setSpacing(int(2 * self.scale))
        self.MainLayout.addLayout(self.checks_l)

        self.enableDisplacement = QCheckBox("Import 3D Assets with Displacement")
        self.enableDisplacement.setToolTip("Enables displacement for 3D Assets")
        self.enableDisplacement.setChecked(self.Importer.getPref("Enable_Displacement"))
        self.enableDisplacement.setFixedHeight(scaled_widget_height)
        self.enableDisplacement.setStyleSheet(self.stylesheet_)
        self.checks_l.addWidget(self.enableDisplacement)

        self.applytoSel.stateChanged.connect(self.settingsChanged)
        self.enableDisplacement.stateChanged.connect(self.settingsChanged)

    def settingsChanged(self):
        """Callback for when settings are changed in the UI."""
        settings_data = self.Importer.loadSettings()
        settings_data["Material_to_Sel"] = self.applytoSel.isChecked()
        settings_data["Enable_Displacement"] = self.enableDisplacement.isChecked()
        self.Importer.updateSettings(settings_data)


# LIVELINK INITIALIZER
def initLiveLink():
    if LiveLinkUI.Instance is not None:
        try:
            LiveLinkUI.Instance.close()
        except:
            pass

    LiveLinkUI.Instance = LiveLinkUI(_importerSetup_)
    LiveLinkUI.Instance.show()

    # Dynamic scaling for the window initialization frame bounds
    scale_factor = LiveLinkUI.Instance.scale
    pref_geo = QRect(
        int(500 * scale_factor),
        int(300 * scale_factor),
        int(330 * scale_factor),
        int(65 * scale_factor),
    )
    LiveLinkUI.Instance.setGeometry(pref_geo)
    return LiveLinkUI.Instance


# LIVELINK MENU INSTALLER LEGACY
def createToolbarMenuPymxsLegacy():

    rt.execute(" global mxsInit = 0 ")
    rt.mxsInit = initLiveLink
    rt.execute("""
-- Sample menu extension script
-- If this script is placed in the "stdplugs\\stdscripts"
-- folder, then this will add the new items to MAX's menu bar
-- when MAX starts.
-- A sample macroScript that we will attach to a menu item
macroScript Megascans
category: "Quixel"
tooltip: "MS Plugin"
(
on execute do mxsInit()
)


-- This example adds a new sub-menu to MAX's main menu bar.
-- It adds the menu just before the "Help" menu.
if menuMan.registerMenuContext 0x1ee76d8f then
(
-- Get the main menu bar
local mainMenuBar = menuMan.getMainMenuBar()
-- Create a new menu
local subMenu = menuMan.createMenu "Megascans"
-- create a menu item that calls the sample macroScript
local subItem = menuMan.createActionItem "Megascans" "Quixel"
-- Add the item to the menu
subMenu.addItem subItem -1
-- Create a new menu item with the menu as it's sub-menu
local subMenuItem = menuMan.createSubMenuItem "Megascans" subMenu
-- compute the index of the next-to-last menu item in the main menu bar
local subMenuIndex = mainMenuBar.numItems() - 1
-- Add the sub-menu just at the second to last slot
mainMenuBar.addItem subMenuItem subMenuIndex
-- redraw the menu bar with the new item
menuMan.updateMenuBar()
)""")


# LIVELINK MENU INSTALLER NEW
def createToolbarMenuPymxsNew():
    # This is the new menu creation method for 3ds Max 2025
    try:

        rt.execute(" global mxsInit = 0 ")
        rt.mxsInit = initLiveLink

        # Define the macro script action details
        macroCategory = "Quixel"
        macroName = "Megascans"

        # Create the macroscript that will be triggered by the menu item
        rt.macros.new(
            macroCategory,  # Category for the macro script
            macroName,  # Name of the macro script
            "MS Plugin",  # Tooltip text
            "Megascans",  # Menu text
            "on execute do mxsInit()",  # Function to execute when the action is triggered
        )

        # Define the menu callback function
        def menuCallback():
            # Get the menu manager from the notification parameter
            menuMgr = rt.callbacks.notificationParam()
            mainMenuBar = menuMgr.mainMenuBar

            # Use unique GUIDs for the menu and menu item
            submenuGUID = "4810d984-1235-40b4-8648-75de85d473a5"
            menuItemGUID = "5da4fbde-0f56-4e31-9b82-ade5aa0e7ec1"

            submenuName = "Megascans"
            submenu = mainMenuBar.createSubMenu(submenuGUID, submenuName)

            macroScriptTableId = 647394
            submenu.createAction(menuItemGUID, macroScriptTableId, "Megascans`Quixel")

        # Register the menu callback on the cuiRegisterMenus event
        MENU_SCRIPT_ID = rt.name("Megascans")
        rt.callbacks.removeScripts(id=MENU_SCRIPT_ID)
        rt.callbacks.addScript(
            rt.name("cuiRegisterMenus"), menuCallback, id=MENU_SCRIPT_ID
        )

        rt.maxOps.getICuiMenuMgr().loadConfiguration(
            rt.maxOps.getICuiMenuMgr().getCurrentConfiguration()
        )

    except Exception as e:
        print(f"{e}")


# Start the LiveLink server here.
_livelink_started = False


def StartSocketServer():
    """Starts the LiveLink socket server."""
    global _livelink_started
    try:
        if len(QLiveLinkMonitor.Instance) == 0:
            bridge_monitor = QLiveLinkMonitor()
            bridge_monitor.Bridge_Call.connect(bridge_monitor.InitializeImporter)
            bridge_monitor.start()
        if not _livelink_started:
            print(f"Quixel Bridge Plugin v{MSLIVELINK_VERSION} started successfully.")
            _livelink_started = True
    except:
        print(f"Quixel Bridge Plugin v{MSLIVELINK_VERSION} failed to start.")
        pass


# The file named builtins calls ours MS_API file from 3ds Max startup - afterwards MS_API is the __main__ file that is run directly with bridge exports
# Start our socket server and setup Megascans menu in the Max Menu bar
if __name__ == "builtins" or __name__ == "__builtin__" or __name__ == "__main__":
    try:
        maxver = int((rt.maxVersion()[0] / 1000.0) - 2.0)
        # Only print version info once
        print(f"MaxVersion: {maxver}")
        if maxver >= 25:
            try:
                createToolbarMenuPymxsNew()
            except Exception as e:
                print(f"Error creating new toolbar menu: {e}")
        else:
            try:
                createToolbarMenuPymxsLegacy()
            except Exception as e:
                print(f"Error creating legacy toolbar menu: {e}")
                raise Exception(e)
    except Exception as err:
        print(
            f"Error encountered while attempting to create Toolbar Menu.\nError: {err}"
        )

    StartSocketServer()
